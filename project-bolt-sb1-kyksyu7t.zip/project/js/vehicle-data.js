// Vehicle data for makes, models, and mileage ranges
const autoMakers = [
  { id: "acura",          name: "Acura" },
  { id: "alfa_romeo",     name: "Alfa Romeo" },
  { id: "aston_martin",   name: "Aston Martin" },
  { id: "audi",           name: "Audi" },
  { id: "bentley",        name: "Bentley" },
  { id: "bmw",            name: "BMW" },
  { id: "bugatti",        name: "Bugatti" },
  { id: "buick",          name: "Buick" },
  { id: "cadillac",       name: "Cadillac" },
  { id: "chevrolet",      name: "Chevrolet" },
  { id: "chrysler",       name: "Chrysler" },
  { id: "dodge",          name: "Dodge" },
  { id: "ferrari",        name: "Ferrari" },
  { id: "fiat",           name: "Fiat" },
  { id: "ford",           name: "Ford" },
  { id: "genesis",        name: "Genesis" },
  { id: "gmc",            name: "GMC" },
  { id: "honda",          name: "Honda" },
  { id: "hyundai",        name: "Hyundai" },
  { id: "infiniti",       name: "Infiniti" },
  { id: "jaguar",         name: "Jaguar" },
  { id: "jeep",           name: "Jeep" },
  { id: "kia",            name: "Kia" },
  { id: "lamborghini",    name: "Lamborghini" },
  { id: "land_rover",     name: "Land Rover" },
  { id: "lexus",          name: "Lexus" },
  { id: "lincoln",        name: "Lincoln" },
  { id: "maserati",       name: "Maserati" },
  { id: "mazda",          name: "Mazda" },
  { id: "mercedes_benz",  name: "Mercedes-Benz" },
  { id: "mini",           name: "Mini" },
  { id: "mitsubishi",     name: "Mitsubishi" },
  { id: "nissan",         name: "Nissan" },
  { id: "porsche",        name: "Porsche" },
  { id: "ram",            name: "Ram" },
  { id: "subaru",         name: "Subaru" },
  { id: "tesla",          name: "Tesla" },
  { id: "toyota",         name: "Toyota" },
  { id: "volkswagen",     name: "Volkswagen" },
  { id: "volvo",          name: "Volvo" }
];

// A subset of the complete vehicle models data for brevity
const vehicleModels = {
  acura: [
    { id:"tl",        name:"TL" },
    { id:"tlx",       name:"TLX" },
    { id:"mdx",       name:"MDX" },
    { id:"rdx",       name:"RDX" },
    { id:"integra",   name:"Integra" }
  ],
  
  audi: [
    { id:"a3",  name:"A3" },
    { id:"a4",  name:"A4" },
    { id:"a5",  name:"A5" },
    { id:"a6",  name:"A6" },
    { id:"q3", name:"Q3" },
    { id:"q5", name:"Q5" },
    { id:"q7", name:"Q7" }
  ],
  
  bmw: [
    { id:"3_series",name:"3 Series" },
    { id:"5_series",name:"5 Series" },
    { id:"7_series",name:"7 Series" },
    { id:"x3",name:"X3" },
    { id:"x5",name:"X5" }
  ],
  
  cadillac: [
    { id:"cts",name:"CTS" },
    { id:"ct4",name:"CT4" },
    { id:"ct5",name:"CT5" },
    { id:"escalade",name:"Escalade" },
    { id:"xt5",name:"XT5" }
  ],
  
  chevrolet: [
    { id:"malibu",name:"Malibu" },
    { id:"impala",name:"Impala" },
    { id:"corvette",name:"Corvette" },
    { id:"camaro",name:"Camaro" },
    { id:"equinox",name:"Equinox" },
    { id:"tahoe",name:"Tahoe" },
    { id:"silverado_1500",name:"Silverado 1500" }
  ],

  ford: [
    { id:"fusion",name:"Fusion" },
    { id:"taurus",name:"Taurus" },
    { id:"mustang",name:"Mustang" },
    { id:"escape",name:"Escape" },
    { id:"explorer",name:"Explorer" },
    { id:"f150",name:"F-150" }
  ],
  
  honda: [
    { id:"accord",name:"Accord" },
    { id:"civic",name:"Civic" },
    { id:"crv",name:"CR-V" },
    { id:"pilot",name:"Pilot" },
    { id:"odyssey",name:"Odyssey" }
  ],

  hyundai: [
    { id:"elantra",name:"Elantra" },
    { id:"sonata",name:"Sonata" },
    { id:"tucson",name:"Tucson" },
    { id:"santa_fe",name:"Santa Fe" },
    { id:"palisade",name:"Palisade" }
  ],
  
  jeep: [
    { id:"wrangler",name:"Wrangler" },
    { id:"grand_cherokee",name:"Grand Cherokee" },
    { id:"cherokee",name:"Cherokee" },
    { id:"compass",name:"Compass" },
    { id:"renegade",name:"Renegade" }
  ],
  
  kia: [
    { id:"forte",name:"Forte" },
    { id:"k5",name:"K5 (Optima)" },
    { id:"sportage",name:"Sportage" },
    { id:"sorento",name:"Sorento" },
    { id:"telluride",name:"Telluride" }
  ],
  
  lexus: [
    { id:"es",name:"ES" },
    { id:"is",name:"IS" },
    { id:"gs",name:"GS" },
    { id:"rx",name:"RX" },
    { id:"nx",name:"NX" }
  ],
  
  mercedes_benz: [
    { id:"c_class",name:"C-Class" },
    { id:"e_class",name:"E-Class" },
    { id:"s_class",name:"S-Class" },
    { id:"glk",name:"GLK/GLC" },
    { id:"gle",name:"GLE" }
  ],
  
  nissan: [
    { id:"altima",name:"Altima" },
    { id:"maxima",name:"Maxima" },
    { id:"rogue",name:"Rogue" },
    { id:"pathfinder",name:"Pathfinder" },
    { id:"frontier",name:"Frontier" }
  ],
  
  toyota: [
    { id:"camry",name:"Camry" },
    { id:"corolla",name:"Corolla" },
    { id:"rav4",name:"RAV4" },
    { id:"highlander",name:"Highlander" },
    { id:"tacoma",name:"Tacoma" },
    { id:"4runner",name:"4Runner" },
    { id:"tundra",name:"Tundra" }
  ],
  
  volkswagen: [
    { id:"jetta",name:"Jetta" },
    { id:"passat",name:"Passat" },
    { id:"tiguan",name:"Tiguan" },
    { id:"atlas",name:"Atlas" },
    { id:"golf",name:"Golf/Golf GTI" }
  ]
};

// Add model data for other makes as needed

// Create mileage ranges for the dropdown
const mileageRanges = [
  { id: "0_10k", name: "0 - 10,000 miles" },
  { id: "10k_20k", name: "10,000 - 20,000 miles" },
  { id: "20k_30k", name: "20,000 - 30,000 miles" },
  { id: "30k_40k", name: "30,000 - 40,000 miles" },
  { id: "40k_50k", name: "40,000 - 50,000 miles" },
  { id: "50k_60k", name: "50,000 - 60,000 miles" },
  { id: "60k_70k", name: "60,000 - 70,000 miles" },
  { id: "70k_80k", name: "70,000 - 80,000 miles" },
  { id: "80k_90k", name: "80,000 - 90,000 miles" },
  { id: "90k_100k", name: "90,000 - 100,000 miles" },
  { id: "100k_plus", name: "100,000+ miles" }
];