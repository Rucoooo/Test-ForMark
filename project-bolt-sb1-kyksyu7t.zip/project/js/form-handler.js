document.addEventListener("DOMContentLoaded", () => {
  // DOM references
  let selMaker = null,
      selModel = null,
      selMileage = null,
      custName = null,
      custPhone = null,
      custEmail = null,
      custZipcode = null;
      
  const md = document.getElementById("maker-dropdown"),
        mdt = document.getElementById("maker-text"),
        mc = document.getElementById("maker-content"),
        od = document.getElementById("model-dropdown"),
        odt = document.getElementById("model-text"),
        oc = document.getElementById("model-content"),
        mileageD = document.getElementById("mileage-dropdown"),
        mileageDT = document.getElementById("mileage-text"),
        mileageC = document.getElementById("mileage-content"),
        cn = document.getElementById("customer-name"),
        cp = document.getElementById("customer-phone"),
        ce = document.getElementById("customer-email"),
        cz = document.getElementById("zipcode"),
        qb = document.getElementById("quote-button"),
        responseMsg = document.getElementById("responseMessage"),
        hiddenForm = document.getElementById("hiddenVehicleForm"),
        hiddenMake = document.getElementById("hidden-make"),
        hiddenModel = document.getElementById("hidden-model"),
        hiddenMileage = document.getElementById("hidden-mileage"),
        hiddenName = document.getElementById("hidden-name"),
        hiddenPhone = document.getElementById("hidden-phone"),
        hiddenEmail = document.getElementById("hidden-email"),
        hiddenZipcode = document.getElementById("hidden-zipcode");

  // Define the URL for the Google Web App
  const GOOGLE_WEB_APP_URL = "https://script.google.com/macros/s/AKfycbzocj2fRbnkqF1j1BUuOa8ycNlLF62SokpfRzmQ1DUMhksJ3jUFd2xXoVcKsxZ5-TjgVA/exec";

  // Populate makes
  autoMakers.forEach((m) => {
    const d = document.createElement("div");
    d.className = "dropdown-item";
    d.textContent = m.name;
    d.onclick = () => {
      selMaker = m;
      mdt.textContent = m.name;
      mc.classList.remove("show");
      od.disabled = false;
      od.classList.remove("opacity-50");
      selModel = null;
      odt.textContent = "Select model";
      oc.innerHTML = "";
      (vehicleModels[m.id] || []).forEach((mod) => {
        const e = document.createElement("div");
        e.className = "dropdown-item";
        e.textContent = mod.name;
        e.onclick = () => selectModel(mod);
        oc.appendChild(e);
      });
      updateButton();
    };
    mc.appendChild(d);
  });

  // Populate mileage ranges
  mileageRanges.forEach((mileage) => {
    const m = document.createElement("div");
    m.className = "dropdown-item";
    m.textContent = mileage.name;
    m.onclick = () => {
      selMileage = mileage;
      mileageDT.textContent = mileage.name;
      mileageC.classList.remove("show");
      updateButton();
    };
    mileageC.appendChild(m);
  });

  function selectModel(mod) {
    selModel = mod;
    odt.textContent = mod.name;
    oc.classList.remove("show");
    updateButton();
  }
  
  // Form input validation
  cn.addEventListener("input", updateButton);
  cp.addEventListener("input", updateButton);
  ce.addEventListener("input", updateButton);
  cz.addEventListener("input", updateButton);
  
  function validatePhone(phone) {
    // Basic US phone validation
    const phonePattern = /^(\+?1[-\s]?)?(\(?\d{3}\)?[-\s]?)?\d{3}[-\s]?\d{4}$/;
    return phonePattern.test(phone);
  }

  function validateZipCode(zipcode) {
    // Basic US ZIP code validation
    const zipPattern = /^\d{5}(-\d{4})?$/;
    return zipPattern.test(zipcode);
  }

  function validateEmail(email) {
    // Basic email validation
    if (!email) return true; // Email is optional
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
  }

  function showValidationError(element, isValid) {
    if (!isValid) {
      element.classList.add('error');
    } else {
      element.classList.remove('error');
    }
  }

  function updateButton() {
    custName = cn.value.trim();
    custPhone = cp.value.trim();
    custEmail = ce.value.trim();
    custZipcode = cz.value.trim();
    
    const phoneValid = validatePhone(custPhone);
    const zipcodeValid = validateZipCode(custZipcode);
    const emailValid = validateEmail(custEmail);
    
    // Show visual cues for invalid fields
    showValidationError(cp, phoneValid || !custPhone);
    showValidationError(cz, zipcodeValid || !custZipcode);
    showValidationError(ce, emailValid);
    
    // All required fields must be filled and valid
    const ok = selMaker && selModel && selMileage && custName && phoneValid && zipcodeValid && emailValid;
    
    qb.disabled = !ok;
    qb.className = ok
      ? "submit-button"
      : "submit-button disabled";
  }

  // Handle form submission
  qb.addEventListener("click", () => {
    if (qb.disabled) return;
    
    // Track form submission
    if (typeof fbq === "function") {
      fbq('track', 'Lead');
      fbq('track', 'CompleteRegistration');
    }
    
    // Populate hidden form values
    hiddenMake.value = selMaker.name;
    hiddenModel.value = selModel.name;
    hiddenMileage.value = selMileage ? selMileage.name : '';
    hiddenName.value = custName;
    hiddenPhone.value = custPhone;
    hiddenEmail.value = custEmail || '';
    hiddenZipcode.value = custZipcode || '';
    
    // Submit form data to Google Web App
    const formData = new FormData(hiddenForm);
    const params = new URLSearchParams(formData);
    
    fetch(GOOGLE_WEB_APP_URL, {
      method: "POST",
      mode: "no-cors",
      body: params
    }).then(() => {
      // Show success message
      responseMsg.classList.remove("hidden");
      responseMsg.classList.add("success");
      responseMsg.querySelector("p").textContent = "Thank you! Your warranty quote request has been submitted. We'll contact you shortly.";
      
      // Define car categories for redirect logic
      const normalCars = ['ford', 'chevrolet', 'gmc', 'cadillac', 'buick', 'chrysler', 'dodge', 'jeep', 'ram', 
        'lincoln', 'tesla', 'volkswagen', 'toyota', 'lexus', 'honda', 'acura', 'nissan', 'infiniti', 'mazda', 
        'subaru', 'mitsubishi', 'hyundai', 'kia', 'genesis', 'mini', 'volvo'];

      const luxuryCars = ['bmw', 'mercedes_benz', 'audi', 'porsche', 'jaguar', 'land_rover'];

      const exoticCars = ['rolls_royce', 'bentley', 'aston_martin', 'maserati', 'ferrari', 'lamborghini'];

      // Set redirect URL based on car category
      let redirectUrl = "/coverage-packages.html"; // Default URL
      
      // Create URL parameters
      const query = new URLSearchParams({
        make: selMaker.id,
        model: selModel.id,
        mileage: selMileage ? selMileage.id : '',
        name: custName,
        phone: custPhone,
        email: custEmail || '',
        zipcode: custZipcode || ''
      }).toString();

      // Short delay before redirect to show the success message
      setTimeout(() => {
        window.location.href = `${redirectUrl}?${query}`;
      }, 1500);
    }).catch((error) => {
      // Show error message
      responseMsg.classList.remove("hidden");
      responseMsg.classList.add("error");
      responseMsg.querySelector("p").textContent = "There was an error submitting your request. Please try again or call us directly.";
      console.error("Error submitting form:", error.message);
    });
  });

  // Toggle dropdowns
  md.onclick = (e) => {
    e.stopPropagation();
    mc.classList.toggle("show");
    oc.classList.remove("show");
    mileageC.classList.remove("show");
  };
  
  od.onclick = (e) => {
    if (od.disabled) return;
    e.stopPropagation();
    oc.classList.toggle("show");
    mc.classList.remove("show");
    mileageC.classList.remove("show");
  };
  
  mileageD.onclick = (e) => {
    e.stopPropagation();
    mileageC.classList.toggle("show");
    mc.classList.remove("show");
    oc.classList.remove("show");
  };
  
  document.addEventListener("click", () => {
    mc.classList.remove("show");
    oc.classList.remove("show");
    mileageC.classList.remove("show");
  });

  // Add animation to testimonial
  const testimonial = document.querySelector('.testimonial');
  if (testimonial) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.transition = "transform var(--transition-normal), opacity var(--transition-normal)";
          entry.target.style.opacity = "1";
          entry.target.style.transform = "translateY(0)";
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });
    
    testimonial.style.opacity = "0";
    testimonial.style.transform = "translateY(20px)";
    observer.observe(testimonial);
  }
});