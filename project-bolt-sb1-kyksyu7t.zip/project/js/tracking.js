// Facebook Pixel Event Tracking
document.addEventListener('DOMContentLoaded', function() {
  var quoteBtn = document.getElementById('quote-button');
  if (quoteBtn) {
    quoteBtn.addEventListener('click', function() {
      if (typeof fbq === "function") {
        fbq('track', 'Lead');
        fbq('track', 'CompleteRegistration');
      }
    });
  }
  
  // Track when users view the form section
  const formSection = document.querySelector('.form-section');
  if (formSection) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting && typeof fbq === "function") {
          fbq('track', 'ViewContent', {
            content_name: 'Quote Form',
            content_category: 'Form View'
          });
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });
    
    observer.observe(formSection);
  }
  
  // Track form field interactions
  const formFields = document.querySelectorAll('.form-input, .form-select');
  formFields.forEach(field => {
    field.addEventListener('focus', function() {
      if (typeof gtag === "function") {
        gtag('event', 'form_field_focus', {
          'field_id': this.id,
          'field_name': this.getAttribute('placeholder') || this.textContent
        });
      }
    });
  });
  
  // Track testimonial visibility
  const testimonial = document.querySelector('.testimonial');
  if (testimonial) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting && typeof gtag === "function") {
          gtag('event', 'view_testimonial', {
            'testimonial_author': document.querySelector('.testimonial-author').textContent
          });
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.8 });
    
    observer.observe(testimonial);
  }
  
  // Phone call tracking
  const phoneLinks = document.querySelectorAll('a[href^="tel:"]');
  phoneLinks.forEach(link => {
    link.addEventListener('click', function() {
      if (typeof gtag === "function") {
        gtag('event', 'phone_call', {
          'event_category': 'Contact',
          'event_label': this.href.replace('tel:', '')
        });
      }
      
      if (typeof fbq === "function") {
        fbq('track', 'Contact');
      }
    });
  });
});

// Set custom dimensions for Google Analytics
if (typeof gtag === "function") {
  gtag('set', 'user_properties', {
    page_template: 'warranty_landing',
    site_version: '1.0.0'
  });
}